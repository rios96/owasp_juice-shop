import { Component } from '@angular/core'

@Component({
  selector: 'warning-card',
  templateUrl: './warning-card.component.html',
  styleUrls: ['./warning-card.component.scss']
})
export class WarningCardComponent {}
